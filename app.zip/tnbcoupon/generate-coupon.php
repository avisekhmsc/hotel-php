<?php
	// include config file
	require_once 'config.php';

	echo couponCodeGenerator();

?>