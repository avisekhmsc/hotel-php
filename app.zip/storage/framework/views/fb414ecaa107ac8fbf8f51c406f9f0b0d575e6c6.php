<?php $__env->startSection('content'); ?>
        <!-- Start Preloader Area -->
        <div class="preloader">
            <div class="loader">
                <div class="shadow"></div>
                <div class="box"></div>
            </div>
        </div>
        <!-- End Preloader Area -->

        <!-- Start Top Header Area -->
        <div class="header-information">Header Information</div>
        
        <?php $page ='home';?>

        <?php echo $__env->make("component.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Start Page Banner -->
            <div class="page-banner-area">
            <div class="container">
                <div class="page-banner-content">
                    <h2>Terrace</h2>
                    
                    <ul class="pages-list">
                        <li><a href="index.html">Home</a></li>
                        <li>Terrace</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- End Page Banner -->
        
        <!-- Start Membership Area -->
        <section class="services-details-area ptb-100">
            <div class="container">
               
                <div class="services-details-overview">
                    <div class="row ">
                        <div class="col-lg-8 col-md-12">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="services-details-image">
                                        <img src="assets/images/terrace1.jpg" alt="image">
                                    </div>
                                </div>
                                <div class="col-md-6 pe-md-0">
                                    <div class="services-details-image">
                                        <img src="assets/images/terrace2.jpg" alt="image">
                                    </div>
                                </div>
                                
                                <div class="col-md-6 ps-md-0">
                                    <div class="services-details-image">
                                        <img src="assets/images/terrace3.jpg" alt="image">
                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="col-lg-4 col-md-12">

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="services-details-desc benefits-content">
                                        <h3 class="mt-0">Terrace</h3>
                                        <p>Host your next event at the beautiful outdoor terrace here at the Miami Financial Center. Our terrace is 4,000 sq.ft
                                            and had a capacity of 150 people.  The space includes lounge seating, stage with lighting, blackjack tables,
                                            surround sound, presentation capabilities and a Full chef’s kitchen.</p>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="events-booking-form mt-4">
                                        <div class="events-booking-title ">
                                            
                                            <h3>Inquire Now </h3>
                                        </div>

                                        <form>
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Full name *">
                                            </div>
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Phone Number">
                                            </div>
                    
                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Your Email*">
                                            </div>

                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="event Type">
                                            </div>

                                            <div class="form-group">
                                                <input type="datetime-local" class="form-control" id="dateTime" name="dateTime" placeholder="Your Preferred Date*">
                                        
                                                
                                            </div>

                                            <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Message">
                                            </div>

                                            <button type="submit" class="default-btn">Submit Now <i class="bx bx-send"></i> <span></span></button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    <div class="row ">
                        
                        
                        
                    </div>
                </div>   
            </div>
        </section>
        <!-- End Membership Area -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('component.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\mfc-laravel\resources\views/terrace.blade.php ENDPATH**/ ?>