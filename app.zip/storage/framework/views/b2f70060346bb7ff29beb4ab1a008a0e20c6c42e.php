
<?php $__env->startSection('content'); ?>
        <!-- Start Preloader Area -->
        <div class="preloader">
        <div class="loader">
        <div class="loader-box-1"></div>
        <div class="loader-box-2"></div>
        </div>
        </div>

        <!-- End Preloader Area -->
        
        <?php $page ='';?>

        <?php echo $__env->make("component.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 
        <main class="main">

<div class="site-breadcrumb">
<div class="site-breadcrumb-wrapper" style="background: url(assets/img/breadcrumb/01.jpg)">
<div class="container">
<h2 class="breadcrumb-title">Schedule a Tour</h2>
<ul class="breadcrumb-menu">
<li><a href="index.html"><i class="far fa-home"></i> Home</a></li>
<li class="active">Schedule a Tour</li>
</ul>
</div>
</div>
</div>
<div class="container my-5">
    <div class="">

    <!-- <ul class="flex f-band">
        <li class="active"><a href="<?php echo e(route('schedule-tour')); ?>"id="selectRoom-tab" onclick="openEvent(event, 'selectRoom')" class="tablinks active">Start Booking</a>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg></li>
        <li><a href="#" class="disable">Choose a room</a>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg></li>
        <li><a href="#"  class="disable">Checkout</a>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-right"><polyline points="9 18 15 12 9 6"></polyline></svg></li>
    </ul> -->

    <form class="row gy-2 gx-3 mt-4  align-items-center" action="<?php echo e(route('schedule-add')); ?>" method="post">        
      <?php echo csrf_field(); ?>
      <div class="col-12 mb-4">
        <input type="text" id="date" name="date" value="<?php echo e(old('date')); ?>" hidden>
        <input type="text" id="time_from" value="<?php echo e(old('time_from')); ?>" name="time_from" hidden>
        <input type="text" id="time_until" value="<?php echo e(old('time_until')); ?>" name="time_until" hidden>
        <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback d-block" style="position: relative"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <?php if($errors->any()): ?>
        <ul style="list-style: circle">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="alert alert-danger"><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        
     <?php endif; ?>
    
        <?php $__errorArgs = ['time_error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div class="alert alert-danger">
<?php echo e($message); ?>

</div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>     
<div class="alert alert-danger d-none" id="error">You have to book minimum 3 hours</div>
        <div id="mousePointer" class="">Drag to Select a range of time</div>
        <div id="timeError" class="alert-danger">Please select time after <span id="time"></span><button onclick="hideTimeError()" type="button">x</button></div>
        <ul class="indications">
          <li><span class="disabled"></span> Disabled</li>
          <li><span class="current"></span> Today</li>
          <li><span class="selected"></span> Selected</li>
          <li><span class="booked"></span> Booked</li>
        </ul>
        <div id='calendar'></div>
      </div>
        
        
          
         
          <!-- <div class="col-auto">
            <label for="">Location</label>
            <input type="text" class="form-control" placeholder="Enter a city">
        </div> -->
       <!-- <div class="col-md-2 text-center">
          
          <button class="theme-mini-btn tablinks w-100" type="submit">Search</button>
        </div> -->
        <div class="row mt-4">
          <div class="col-md-4">
          <div class="form-group">
          <label for="radioSelect" class="them-color">Looking For:</label>
          </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
            <div class="form-check">
              <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="virtual office" <?php if(old('exampleRadios') == "virtual Tour"): ?> checked  <?php endif; ?> <?php if(!old('exampleRadios')): ?> checked <?php endif; ?>>
              <label class="form-check-label" for="exampleRadios1">
                  Virtual Tour
              </label>
            </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
            <div class="form-check">
              <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="In person Tour" <?php if(old('exampleRadios') == "In person Tour"): ?> checked <?php endif; ?>>
              <label class="form-check-label" for="exampleRadios2">
                In person Tour
              </label>
            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
          <div class="form-group mb-4">
          <input type="text" class="form-control" name="name" placeholder="Your Name" value="<?php echo e(old('name')); ?>" required>
          <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          </div>
          <div class="col-md-6">
          <div class="form-group mb-4">
          <input type="email" class="form-control" name="email" placeholder="Your Email" value="<?php echo e(old('email')); ?>" required>
          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
          <div class="form-group">
          <input type="number" class="form-control" name="phone" placeholder="Phone" value="<?php echo e(old('phone')); ?>" required>
          <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          </div>
          <div class="col-md-6">
          <div class="form-group mb-4">
            <label for="space_type" class="form-label them-color">Space Type:</label>
            <input class="form-check-input" type="checkbox" id="space_type[]" name="space_type[]" value="office">
            <label class="form-check-label" for="office"> Office</label>

            <input class="form-check-input" type="checkbox" name="space_type[]" value="terrace">
            <label class="form-check-label" for="terrace">Terrace</label>
            <?php $__errorArgs = ['space_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
          <div class="form-group  mb-4">
            <textarea name="message" cols="30" rows="5" class="form-control" placeholder="Write Your Message"><?php echo e(old('message')); ?></textarea>
            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <button type="submit" class="theme-btn">Schedule Tour </button>
          </div>
          <div class="col-md-8">
          <div class="form-messege text-success"></div>
          </div>
        </div>
        <?php if(session()->get('error')): ?>
        <div class="alert alert-warning">
            <?php echo e(session()->get('error')); ?>

        </div>
    <?php endif; ?>
      </form>
      
</div>

                <?php
                $arr = array(); 
date_default_timezone_set('Asia/Kolkata');
$date = date("Y-m-d");
$time = date('h:i:s');
                foreach($schedule_tours as $schedule_tour){
                //   $dateCreate=date_create($schedule_tour->date);
                //  $dateSub = date_sub($dateCreate,date_interval_create_from_date_string("1 day"));
                   
                array_push($arr,array(
                'title'=>$schedule_tour->name,
                'start'=>$schedule_tour->meeting_date.'T'.$schedule_tour->time_from,
                'end'=>$schedule_tour->meeting_date.'T'.$schedule_tour->time_until,
                'backgroundColor'=>'green',
                'borderColor'=>'green'
                ));
                }
                
                ?>   
              
</main>
<script>
  document.addEventListener('DOMContentLoaded', function() {
      var calendarEl = document.getElementById('calendar');
    //   let arr = [{
    //   start: '2023-07-10',
    //   end: '2023-07-18',
    //   display: 'background'
    // }];
      // console.log(new Date(Date.parse(arr[0].end)).getFullYear());
      let bg = 'background';
  let arr = <?php echo json_encode($arr); ?>;
      var calendar = new FullCalendar.Calendar(calendarEl, {
        // initialView: 'dayGridMonth',
        initialView: 'timeGridWeek',
        selectable: true,
        editable: true,
        disableDragging: true,
        allDay:false,
        // timeZone: 'local',
      
  events: arr,
// validRange: {
//     // start: '2023-07-10T08:00:00',
//     start: '<?php echo $date."T".$time ?>',
//     end: ''
//   },
  // [
  //   {
  //     title: 'Admin',
  //     start: '2023-07-13T07:00:00',
  //     backgroundColor: 'green',
  //     borderColor: 'green'
  //   },
  //   {
  //     title: 'Subrata',
  //     start: '2023-07-02T08:00:00',
  //     end: '2023-07-02T09:00:00',
  //     backgroundColor: 'green',
  //     borderColor: 'green'
  //   }
  // ],
  select: function(selectionInfo ) {
           console.log(selectionInfo);
           let startDate = new Date(selectionInfo.startStr);
           let currentDate = new Date();
           let currentMonth = currentDate.getMonth()+1;
           if(currentMonth.toString().length < 2){
            currentMonth = "0"+currentMonth;
           }
           let currentHour = currentDate.getHours();
           let currentMinute = currentDate.getMinutes();
           console.log("startDate : "+startDate);
           console.log("currentDate : "+currentDate);
          
           let startHour = startDate.getHours();
           let startMinute = startDate.getMinutes();
           let endDate = new Date(selectionInfo.endStr);
           let endHour = endDate.getHours();
           let endtMinute = endDate.getMinutes();
           let year = startDate.getFullYear();
           let month = startDate.getMonth()+1;
           let day = startDate.getDate();
          //  if(endtMinute !== 0){
          //    endtMinute = endtMinute-30;
          //  }
           if(month.toString().length < 2){
             month = "0"+month;
           }
           if(day.toString().length < 2){
             day = "0"+day;
           }
           if(startHour == 0){
            startHour = 24; 
           }
           else{
            if(startHour.toString().length < 2){
            startHour = "0"+startHour;
           }
           }          
           if(startMinute.toString().length < 2){
            startMinute = "0"+startMinute;
           }
           if(endHour == 0){
             endHour = 24;
           }
           else{
            if(endHour.toString().length < 2){
            endHour = "0"+endHour;
           }
           }           
           if(endtMinute.toString().length < 2){
            endtMinute = "0"+endtMinute;
           }
           console.log(startHour);
           let fullDate = year+"-"+month+"-"+day;
           let time_from = startHour+":"+startMinute;
           let time_until = endHour+":"+endtMinute;
           
    // console.log("hour " + (parseInt(endHour) - parseInt(startHour)));
    if(startDate < currentDate){
            document.getElementById("timeError").classList.add("show");
            document.getElementById("time").innerText=currentDate.getFullYear()+"-"+currentMonth+"-"+currentDate.getDate()+" "+currentHour+":"+currentMinute;
            document.querySelector("form .theme-btn").classList.add('disabled');
            // document.querySelector("#error").classList.remove('d-none');
    }
    else{
      document.getElementById('date').setAttribute('value',fullDate);
           document.getElementById('time_from').setAttribute('value',time_from);
           document.getElementById('time_until').setAttribute('value',time_until);
      document.getElementById("timeError").classList.remove("show");
      document.querySelector("form .theme-btn").classList.remove('disabled');
      if(parseInt(startHour) == 24){
        startHour = 0;
      }
      if(parseInt(endHour) == 24){
        endHour = 0;
      }
    //   if(parseInt(endHour) - parseInt(startHour) > 2){
    //   document.querySelector("form .theme-btn").classList.remove('disabled');
    //   document.querySelector("#error").classList.add('d-none');
    // }
    // else{
    //   document.querySelector("form .theme-btn").classList.add('disabled');
    //   document.querySelector("#error").classList.remove('d-none');
    // }
    console.log("start" +startHour);
    console.log("end" +endHour);
    console.log(parseInt(endHour) - parseInt(startHour));
    }
      },
      });
      calendar.render();
//   var calendar = new Calendar(calendarEl, {
//   timeZone: 'local', // the default (unnecessary to specify)
//   events: [
//     { start: '2018-09-01T12:30:00Z' }, // will be shifted to local
//     { start: '2018-09-01T12:30:00+XX:XX' }, // already same offset as local, so won't shift
//     { start: '2018-09-01T12:30:00' } // will be parsed as if it were '2018-09-01T12:30:00+XX:XX'
//   ],
//   dateClick: function(arg) {
//     console.log(arg.date.toString()); // use *local* methods on the native Date Object
//     // will output something like 'Sat Sep 01 2018 00:00:00 GMT-XX:XX (Eastern Daylight Time)'
//   }
// });
    });
    document.querySelector("#calendar").addEventListener("mouseover",function(e){
document.getElementById("mousePointer").classList.add("show");
document.getElementById("mousePointer").style.top=(e.screenY - 100)+"px";
document.getElementById("mousePointer").style.left=e.screenX+"px";
    });
    function hideTimeError(){
      document.getElementById("timeError").classList.remove("show");
}
    document.querySelector("#calendar").addEventListener("mouseleave",function(e){
      document.getElementById("mousePointer").classList.remove("show");
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('component.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\mfc2-laravel\resources\views/schedule-tour.blade.php ENDPATH**/ ?>