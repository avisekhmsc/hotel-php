<!doctype html>

<html lang="zxx">

<body>



    <!-- Mirrored from templates.envytheme.com/MFC/default/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 23 Mar 2023 04:57:27 GMT -->

<head>

    <!-- Required meta tags -->

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">



    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

    

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/all-fontawesome.min.css')); ?>">



    <link rel="stylesheet" href="<?php echo e(asset('assets/css/flaticon.css')); ?>">

    

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.min.css')); ?>">

    

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/magnific-popup.min.css')); ?>">

     

    <!-- Nice Select CSS -->

     



    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">

    

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

    



    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.10.0/css/bootstrap-datepicker.min.css">



     <!-- jQuery UI datepicker -->

     <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">

    

    <title>WELCOME TO RESET PASSWORD</title>



    <link rel="icon" type="image/png" href="assets/images/favicon.png">

</head>
<body class="form">
    
        <div class="login-area py-5">
            <div class="container">
            <div class="col-md-5 mx-auto">
            <div class="login-form">
            <div class="login-header mb-4">
                <div align="center"><img src="https://hisabsoftwares.com/tnb/public/admin_panel_logo/1575359863-logo.png" height="70" width="220">
                </div>
            <h3>Reset Password</h3>
            </div>
                        <form action="<?php echo e(route('change-password')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php if(Session('error')): ?>
                             <div class="alert alert-danger" role="alert">
                              <?php echo e(Session('error')); ?>

                            </div>                          
                            <?php endif; ?>
                        
                        <div class="form-group">
                        <label>Old Password</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="old_password" value="<?php echo e(old('old_password')); ?>" required autofocus>
                        <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                        <label>New Password</label>
                        <input id="password" type="password" class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="new_password" required >
                        <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label>Confirm Password</label>
                            <input id="password" type="password" class="form-control <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="confirm_password" required >
                            <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        
                        <div class="d-flex align-items-center mb-3">
                        <button type="submit" class="btn btn-primary theme-btn">Submit<i class="far fa-sign-in"></i></button>
                        </div>
                        </form>
                        <p class="terms-conditions text-center">© 2023 All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </div>
       
 


    <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
    <script src="<?php echo e(asset('public/assets/js/libs/jquery-3.1.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/bootstrap/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('public/bootstrap/js/bootstrap.min.js')); ?>"></script>

    <!-- END GLOBAL MANDATORY SCRIPTS -->
    <script src="<?php echo e(asset('public/assets/js/authentication/form-1.js')); ?>"></script>

</body>
</html>





<?php /**PATH /home/hisab165/public_html/tnborders.com/resources/views/backend/reset-password.blade.php ENDPATH**/ ?>