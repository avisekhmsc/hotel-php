
<?php $__env->startSection('content'); ?>
        <!-- Start Preloader Area -->
        <div class="preloader">
            <div class="loader">
                <div class="shadow"></div>
                <div class="box"></div>
            </div>
        </div>
        <!-- End Preloader Area -->

        <!-- Start Top Header Area -->
        <div class="header-information">Header Information</div>
        
        <?php $page ='home';?>

        <?php echo $__env->make("component.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <!-- Start Page Banner -->
        <div class="page-banner-area">
            <div class="container">
                <div class="page-banner-content">
                    <h2> Team </h2>
                    
                    <ul class="pages-list">
                        <li><a href="index.php">Home</a></li>
                        <li>Team</li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- End Page Banner -->
                <!-- Start Video Area -->
        <!-- <div class="video-area-without-color ptb-100">
            <div class="container">
                <div class="video-image-content">
                    <a href="https://www.youtube.com/watch?v=ODfy2YIKS1M" class="video-btn popup-youtube">
                        <i class='bx bx-play'></i>
                    </a>
                    
                    <div class="content-text">
                        <span>Coworking</span>
                        <h3>Check This Video Presentation To Know More About Our Coworking</h3>
                    </div>
                </div>
            </div>
        </div> -->
        <!-- End Video Area -->
  
       
 <!-- Start Team Area -->
        <div class="pt-100 pb-70">
            <div class="container">
                <div class="section-title">
                    <span>Multi-Office Team</span>
                    <h2>Our Modern Office Spaces Are Simply Stunning & Comfortable</h2>
                </div>

                <div class="row justify-content-center">
                    <div class="col-lg-6 col-md-6 mb-4 mb-sm-0">
                        <div class="single-team-box h-100">
                            <div class="image">
                                <img src="assets/images/team/Noland.jpg" alt="image">

                                <ul class="social">
                                    <li>
                                        <a href="#" target="_blank">
                                            <i class='bx bxl-facebook'></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank">
                                            <i class='bx bxl-twitter'></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank">
                                            <i class='bx bxl-linkedin'></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank">
                                            <i class='bx bxl-instagram-alt'></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            <div class="content">
                                <h3>Noland Langford, MBA, CFP®</h3>
                                <span>PRESIDENT & CEO</span>
                                <p>Noland is CEO and CIO (Chief Investment Officer) for Left Brain. He works with High Net worth investors on Investment strategies and aids them in wealth accumulation, tax efficient investing and retirement Income planning. </p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 col-md-6 mb-4 mb-sm-0">
                        <div class="single-team-box h-100">
                            <div class="image">
                                <img src="assets/images/team/china2.jpg" alt="image">

                                <ul class="social">
                                    <li>
                                        <a href="#" target="_blank">
                                            <i class='bx bxl-facebook'></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank">
                                            <i class='bx bxl-twitter'></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank">
                                            <i class='bx bxl-linkedin'></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank">
                                            <i class='bx bxl-instagram-alt'></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>

                            <div class="content">
                                <h3>DelChina Thompson</h3>
                                <span>Director & Project Manager</span>
                                <p>DelChina is the Director and Project Manager for the MFC. She has years of experience managing high level projects in a wide range of areas. DelChina is a graduate of the University of Maryland University College and an U.S. Army Veteran.</p>
                            </div>
                        </div>
                    </div>

                    
                </div>
            </div>
        </div>
        <!-- End Team Area -->
        
        
        <!-- Start Work Area -->
        <!-- <div class="work-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="work-image two"></div>
                    </div>

                    <div class="col-lg-6">
                        <div class="work-content-item">
                            <div class="content-box">
                                <b>Give a Boost On Your Work</b>
                                <h3>Team or Individuals Sustainable Coworking in Your Town</h3>
                                <p>Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris.</p>

                                <div class="row justify-content-center">
                                    <div class="col-lg-4 col-md-4">
                                        <div class="work-fun-fact">
                                            <h4>
                                                <span class="odometer" data-count="3500">00</span>
                                                <span class="sign-icon">m2</span>
                                            </h4>
                                            <p>Coworking Space</p>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-4">
                                        <div class="work-fun-fact">
                                            <h4>
                                                <span class="odometer" data-count="1890">00</span>
                                                <span class="sign-icon">People</span>
                                            </h4>
                                            <p>Office Amount</p>
                                        </div>
                                    </div>

                                    <div class="col-lg-4 col-md-4">
                                        <div class="work-fun-fact">
                                            <h4>
                                                <span class="odometer" data-count="426">00</span>
                                                <span class="sign-icon">+</span>
                                            </h4>
                                            <p>Available Space Now</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <!-- End Work Area -->

        <!-- Start Video Area -->
        <!-- <div class="video-area-without-color ptb-100">
            <div class="container">
                <div class="video-image-content">
                    <a href="https://www.youtube.com/watch?v=ODfy2YIKS1M" class="video-btn popup-youtube">
                        <i class='bx bx-play'></i>
                    </a>
                    
                    <div class="content-text">
                        <span>Coworking</span>
                        <h3>Check This Video Presentation To Know More About Our Coworking</h3>
                    </div>
                </div>
            </div>
        </div> -->
        <!-- End Video Area -->

       
        
        <!-- Start Review Area -->
        <!-- <div class="review-area ptb-100">
            <div class="container">
                <div class="review-slides owl-carousel owl-theme">
                    <div class="row align-items-center">
                        <div class="col-lg-7">
                            <div class="review-item">
                                <div class="review-text">
                                    <p>“Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis nisi elit consequat ipsum, nec sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris.”</p>
                                </div>
    
                                <div class="review-info">
                                    <h3>Thomas Medison</h3>
                                    <span>UI/UX Designer</span>
                                </div>
                            </div>

                            <div class="review-saying">
                                <h4>See What Other People are Saying</h4>

                                <div class="rating">
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <a href="#" class="rating-count">4.56 / 5.0</a>
                                </div>

                                <div class="saying-btn">
                                    <a href="about.html" class="default-btn">Read Reviews <i class='bx bxs-chevron-right'></i><span></span></a>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-5">
                            <div class="review-image">
                                <img src="assets/images/review/review-1.jpg" alt="image">

                                <div class="icon">
                                    <i class='bx bxs-quote-right'></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row align-items-center">
                        <div class="col-lg-7">
                            <div class="review-item">
                                <div class="review-text">
                                    <p>“Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis nisi elit consequat ipsum, nec sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris.”</p>
                                </div>
    
                                <div class="review-info">
                                    <h3>Sarah Taylor</h3>
                                    <span>Web Developer</span>
                                </div>
                            </div>

                            <div class="review-saying">
                                <h4>See What Other People are Saying</h4>

                                <div class="rating">
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <a href="#" class="rating-count">4.56 / 5.0</a>
                                </div>

                                <div class="saying-btn">
                                    <a href="about.html" class="default-btn">Read Reviews <i class='bx bxs-chevron-right'></i><span></span></a>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-5">
                            <div class="review-image">
                                <img src="assets/images/review/review-2.jpg" alt="image">

                                <div class="icon">
                                    <i class='bx bxs-quote-right'></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row align-items-center">
                        <div class="col-lg-7">
                            <div class="review-item">
                                <div class="review-text">
                                    <p>“Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis nisi elit consequat ipsum, nec sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris.”</p>
                                </div>
    
                                <div class="review-info">
                                    <h3>Richard Turner</h3>
                                    <span>Web Designer</span>
                                </div>
                            </div>

                            <div class="review-saying">
                                <h4>See What Other People are Saying</h4>

                                <div class="rating">
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <i class='bx bxs-star'></i>
                                    <a href="#" class="rating-count">4.56 / 5.0</a>
                                </div>

                                <div class="saying-btn">
                                    <a href="about.html" class="default-btn">Read Reviews <i class='bx bxs-chevron-right'></i><span></span></a>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-5">
                            <div class="review-image">
                                <img src="assets/images/review/review-3.jpg" alt="image">

                                <div class="icon">
                                    <i class='bx bxs-quote-right'></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->
        <!-- End Review Area -->

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('component.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\mfc-laravel\resources\views/team.blade.php ENDPATH**/ ?>