

<?php $__env->startSection('content'); ?>
<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing">
    <div class="statbox widget box box-shadow">
        <div class="widget-content widget-content-area">
          <?php if(session('alert')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('alert')); ?>

    </div>
<?php endif; ?>
          <div class="row">
            <div class="col-md-6">
              <div class="d-flex justify-content-between mb-4">
                <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="slot_id" value="<?php echo e($slot->id); ?>" id="slot<?php echo e($slot->id); ?>" onclick="activeCategory()" <?php if(session('alert')): ?> disabled <?php endif; ?>>
                  <label class="form-check-label" for="slot<?php echo e($slot->id); ?>">
                    <?php echo e($slot->slot); ?>

                  </label>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
             
            </div>
              <div class="form-group">
                <label for="exampleFormControlSelect1">Select category</label>
                <select class="form-control js-example-basic-multiple" id="exampleFormControlSelect1" onchange="fetchMenu(this)" disabled>
                    <option value="">Select category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                  
                </select>
              </div>
              
            </div>
          </div>
           <div class="data-list d-none">
             <div id="showList"></div>
               
               <div class="col-md-8 mx-auto">
                <div class="d-flex justify-content-between">
                  <label for=""><b>Total Amount</b></label>
                  <span><b id="total-amount"></b></span>
                </div>
               </div>
              
            
              
              
              
          
        
           </div>
           <button class="ml-auto d-none btn btn-success px-5" id="saveBtn" onclick="saveOrder()">Save</button>
                </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\august01\resources\views/backend/user-orders/index.blade.php ENDPATH**/ ?>