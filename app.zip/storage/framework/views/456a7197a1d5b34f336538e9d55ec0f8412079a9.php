
<?php $__env->startSection('content'); ?>
        <!-- Start Preloader Area -->
        <div class="preloader">
        <div class="loader">
        <div class="loader-box-1"></div>
        <div class="loader-box-2"></div>
        </div>
        </div>

        <!-- End Preloader Area -->
        
        <?php $page ='';?>

        <?php echo $__env->make("component.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 
        <main class="main">

<div class="site-breadcrumb">
<div class="site-breadcrumb-wrapper" style="background: url(assets/img/breadcrumb/01.jpg)">
<div class="container">
<h2 class="breadcrumb-title">Book Online</h2>
<ul class="breadcrumb-menu">
<li><a href="<?php echo e(route('home')); ?>"><i class="far fa-home"></i> Home</a></li>
<li class="active">Book Online</li>
</ul>
</div>
</div>
</div>
<div class="container my-5">
    <div class="schedule-tour">

    <ul class="flex f-band">
        <li class="active"><a href="<?php echo e(route('schedule-tour')); ?>"id="selectRoom-tab" onclick="openEvent(event, 'selectRoom')" class="tablinks active">Start Booking</a>
            
          </li>
        
        
    </ul>
    <div class="contact-form">
      

      <form class="row gy-2 gx-3 mt-4  align-items-center" action="<?php echo e(route('book-check')); ?>" method="get">        
        <?php echo csrf_field(); ?>
        <!-- <div class="row">
          <div class="col-md-4">
          <div class="form-group">
          <label for="radioSelect" class="them-color">Looking For:</label>
          </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
            <div class="form-check">
              <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
              <label class="form-check-label" for="exampleRadios1">
                  Virtual Tour
              </label>
            </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="form-group">
            <div class="form-check">
              <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
              <label class="form-check-label" for="exampleRadios1">
                In person Tour
              </label>
            </div>
            </div>
          </div>
        </div> -->
        <div class="row mb-5">
          <div class="col-md-6 col-lg-4">
            <input type="radio" id="month1" value="30" name="month" <?php if(old('month') == "30"): ?> selected <?php endif; ?> hidden>
            <label for="month1">
            <div class="agreement-length">
              <div class="agreement-header-wrapper">
                <div class="agreement-header">
                    <h5>Monthly Agreement</h5>
                </div>
                <div class="pricing-amount">
                  <strong> $153</strong>
                </div>
              </div>
            </div>
          </label>
          </div>
          <div class="col-md-6 col-lg-4">
            <input type="radio" id="month2" value="180" name="month" <?php if(old('month') == "180"): ?> selected <?php endif; ?> hidden>
            <label for="month2">
            <div class="agreement-length">
              <div class="agreement-header-wrapper">
                <div class="agreement-header">
                    <h5>6 Months Agreement</h5>
                </div>
                <div class="pricing-amount">
                
                  <strong> $183</strong>
                </div>
              </div>
            </div>
            </label>
          </div>
          <div class="col-md-6 col-lg-4">
            <input type="radio" id="month3" value="360" name="month" <?php if(old('month') == "360"): ?> selected <?php endif; ?> hidden>
            <label for="month3">
            <div class="agreement-length">
              <div class="agreement-header-wrapper">
                <div class="agreement-header">
                    <h5>Yearly Agreement</h5>
                </div>
                <div class="pricing-amount">
                  <strong> $253</strong>
                </div>
              </div>
            </div>
            </label>
          </div>
          <?php $__errorArgs = ['month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback d-block mt-5" style="position: relative;z-index:9"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
         
        <div class="row mt-2">
          <div class="col-md-6">
          <div class="form-group">
          <input type="text" class="form-control" name="name" placeholder="Your Name" value="<?php echo e(old('name')); ?>" required>
          <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback d-block mt-5"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          </div>
          <div class="col-md-6">
          <div class="form-group">
          <input type="email" class="form-control" name="email" placeholder="Your Email" value="<?php echo e(old('email')); ?>"  required>
          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback d-block mt-5"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          </div>
          <div class="col-md-6">
          <div class="form-group">
          <input type="number" class="form-control" name="phone" placeholder="Phone" value="<?php echo e(old('phone')); ?>"  required>
          <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback d-block mt-5"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          </div>
          
          <div class="col-6">
                
            
            <div class="form-group">
            <input type="date" class="form-control" name="date" id="date" min="2023-06-20" value="<?php echo e(old('date')); ?>" >
            </div>
            <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>       
            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback d-block mt-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <!-- <div class="col-md-6">
            <div class="form-group ">
              <label for="space_type" class="them-color">Space Type:</label> 
              <input class="form-check-input" type="checkbox" id="space_type[]" name="space_type[]" value="Office">
              <label class="form-check-label" for="virtual">Virtual Office</label>

              <input class="form-check-input" type="checkbox" id="space_type[]" name="space_type[]" value="Terrace">
              <label class="form-check-label" for="terrace">Terrace</label>
            </div>
          </div> -->
        </div>
        <div class="row">
          <div class="col-md-12">
          <div class="form-group">
            <textarea name="message" cols="30" rows="5" class="form-control" value="<?php echo e(old('message')); ?>" placeholder="Write Your Message"><?php echo e(old('message')); ?></textarea>
            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback d-block mt-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <button type="submit" class="theme-btn">Search </button>
          </div>
          <div class="col-md-8">
          <div class="form-messege text-success"></div>
          </div>
        </div>
      </form>
    </div>
</div>
</div>
          



<?php
$arr = array(); 
foreach($booking_details as $booking_detail){
array_push($arr,array('start'=>$booking_detail->starting_date,
'end'=>$booking_detail->end_date,
'display'=>'background'
));
}

?>
</main>
<script>
 
    document.addEventListener('DOMContentLoaded', function() {
        var calendarEl = document.getElementById('calendar');
        let arr = <?php echo json_encode($arr); ?>;
        // console.log(new Date(Date.parse(arr[0].end)).getFullYear());
        let bg = 'background';
        var calendar = new FullCalendar.Calendar(calendarEl, {
          initialView: 'dayGridMonth',
          selectable: true,
          events: arr,
          select: function(selectionInfo ) {
            let strDate = selectionInfo.startStr;
            let inputDate = document.getElementById("date");
				console.log(selectionInfo.startStr);        
        console.log(inputDate.min <= selectionInfo.startStr);
        if(inputDate.min <= selectionInfo.startStr){
          inputDate.value=strDate;
        }
        else{
          alert("You can not add this date");
        }
				// console.log(selectionInfo.endStr);
				// alert(end);
				// $('#event_start_date').val(moment(start).format('YYYY-MM-DD'));
				// $('#event_end_date').val(moment(end).format('YYYY-MM-DD'));
				// $('#event_entry_modal').modal('show');
			},
        });
        calendar.render();
      });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('component.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\mfc2-laravel\resources\views/book-online.blade.php ENDPATH**/ ?>