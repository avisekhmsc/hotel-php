

<?php $__env->startSection('content'); ?>
<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing">
    <div class="statbox widget box box-shadow">
        <div class="widget-content widget-content-area">
          
          <?php if(Session::has('name')): ?>
          <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                
                  <button type="button" class="close text-right pt-3 pr-3" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>                             <div class="modal-body text-center">
                  <h6 style="color:#719B5f;"><?php echo e(Session::get('name')); ?>.</h6>
                  <h6 style="color:#719B5f;">You have successfully logedin !</h6>
                </div>
                
              </div>
            </div>
          </div>
<?php endif; ?>
          <?php if(session('alert')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('alert')); ?>

    </div>
<?php endif; ?>
          <div class="row">
            <div class="col-md-6">
              <div class="d-flex justify-content-between mb-4">
                
                <?php $count = 0; ?>
                <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php $status = "";  ?>
               <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php 
               if($item->slot_id == $slot->id){
                $status = "disabled";
                $count++;
               } 
               ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php
                if(Session::has('user_type') && Session::get('user_type') == 'User'){
                $t=time()+3600;
                $hr = intVal(date("H",$t));
                $m = intVal(date("i",$t));
                if($hr >= 22 && $hr < 23){
                 if($m > 30){
                $status = "disabled";
                }
                }
                elseif($hr > 22){
                $status = "disabled";
                }
                }
                ?>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="slot_id" value="<?php echo e($slot->id); ?>" id="slot<?php echo e($slot->id); ?>" onclick="activeCategory()" <?php echo e($status); ?>  <?php if(session('alert')): ?> disabled <?php endif; ?>>
                  <label class="form-check-label" for="slot<?php echo e($slot->id); ?>">
                    <?php echo e($slot->slot); ?>

                  </label>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
             
            </div>
              <?php
              if(Session::has('user_type') && Session::get('user_type') == 'User'){
            $t=time();
$hr = intVal(date("H",$t));
$m = intVal(date("i",$t));
if($hr >= 22 && $hr < 23){
    if($m > 30){
  ?>
    <div class="alert alert-danger">
      Order taking has been closed for the day
  </div>
  <?php
    }
}
elseif($hr > 22){
    ?>
    <div class="alert alert-danger">
      Order taking has been closed for the day
  </div>
  <?php
}
}
?>
            <?php if($count > 2): ?>
            <div class="alert alert-danger">
              You Can't add more for today
          </div>
          <?php endif; ?>
              <div class="form-group">
                <label for="exampleFormControlSelect1">Select category</label>
                <select class="form-control js-example-basic-multiple" id="exampleFormControlSelect1" onchange="fetchMenu(this)" disabled>
                    <option value="">Select category</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                  
                </select>
              </div>
              
            </div>
          </div>
           <div class="data-list d-none">
             <div id="showList"></div>
               
               <!--<div class="col-md-8 mx-auto">-->
               <!-- <div class="d-flex justify-content-between">-->
               <!--   <label for=""><b>Total Amount</b></label>-->
               <!--   <span><b id="total-amount"></b></span>-->
               <!-- </div>-->
               <!--</div>-->
              
            
              
              
              
          
        
           </div>
            <div class="w-100"
            style="
    position: fixed;
    bottom: 0;
    background: #fff;
    width: 100%;
    left: 0;
    z-index: 99999999;
    padding: 18px 56px;
    border-top: 1px solid #85858533;
">
            <div class="d-flex justify-content-end">
              <label for="" class="mr-3 mb-0"><b>Total Amount</b></label>
              <span>Rs.<b id="total-amount"></b></span>
            </div>
           </div>
           <button class="ml-auto d-none btn btn-success px-5" id="saveBtn" onclick="saveOrder()">Save</button>
                </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hisab165/public_html/tnborders.com/resources/views/backend/user-orders/index.blade.php ENDPATH**/ ?>