<?php
echo $data['body'];?><?php /**PATH /home/hisab165/public_html/tnborders.com/resources/views/mail.blade.php ENDPATH**/ ?>