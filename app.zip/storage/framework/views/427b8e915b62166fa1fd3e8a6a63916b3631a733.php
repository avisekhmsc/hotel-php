

<?php $__env->startSection('content'); ?>
<div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-rowx">
        <div id="wizards_pills" class="col-lg-12">
            <div class="seperator-header">
               
                
            </div>
            <?php if(session()->get('error')): ?>
                <div class="alert alert-warning">
                    <?php echo e(session()->get('error')); ?>

                </div>
            <?php endif; ?>
        </div>
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing">
             <div class="statbox widget box box-shadow">
                 <div class="widget-content widget-content-area">
                     <table id="datatable-tabletools" class="table table-hover non-hover individual-col-search" style="width:100%">
                         <thead>
                             <tr>
                                 
                                 <!-- <th>Meeting Type</th> -->
                                 <th>Meeting Date</th>     
                                 <th>Time From</th>
                                 <th>Time Until</th>
                                 <th>Looking For</th>
                                 <th>Name</th> 
                                 <th>Email</th> 
                                 <th>Phone</th>
                                 <th>Space Type</th> 
                                 <th>Message</th> 
                                 <th>Action</th> 

                             </tr>
                             <?php $count = 0; ?>
                            
                         </thead>
                         <tbody>
                         <?php $__currentLoopData = $scheduleList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($list->meeting_date); ?></td>
                                <td><?php echo e($list->time_from); ?></td>
                                <td><?php echo e($list->time_until); ?></td>
                                <td><?php echo e($list->looking_for); ?></td>
                                <td><?php echo e($list->name); ?></td>
                                <td><?php echo e($list->email); ?></td>
                                <td><?php echo e($list->phone); ?></td>
                                <td><?php echo e($list->space_type); ?></td>
                                <td><?php echo e($list->message); ?></td>
                                <td> <div class="d-flex">
                                    <a href="#" class="edit-btn btn btn-warning mr-2">Schedule</a>
                                    <a href="#" class="btn btn-danger">Delete</a>
                            </div></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </tbody>
                         
                     </table>
                 </div>
             </div>
         </div>
     </div>
 </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\mfc2-laravel\resources\views/backend/schedule/schedule-list.blade.php ENDPATH**/ ?>