<?php $__env->startSection('content'); ?>
<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing">
    <div class="statbox widget box box-shadow">
        <div class="widget-content widget-content-area">
            <table class="table">
                <thead>
                    <th>Id</th> 
                    <?php if(isset($username)): ?>                    
                        <th>User Code</th>
                        <th>User Name</th>
                    <?php endif; ?>                   
                    <th>Slot</th>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Amount (Rs.)</th>
                    <th>Created At</th>
                </thead>
                <tbody>
                    <?php $total = 0; ?>
                    <?php $total_qty = 0; ?>
                    <?php $__currentLoopData = $order_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php $total = $total + $item->amount; ?>
                   <?php $total_qty += $item->qty; ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <?php if(isset($item->name)): ?>
                            <td><?php echo e($item->CUSTCODE); ?></td>
                            <td><?php echo e($item->name); ?></td>
                        <?php endif; ?>                     
                        <td><?php echo e($item->slot); ?></td>
                        <td><?php echo e($item->item_name); ?></td>
                        <td><?php echo e($item->price); ?></td>
                        <td><?php echo e($item->qty); ?></td>
                        <td><?php echo e($item->amount); ?></td>
                        <td><?php echo e(date('d-m-Y', strtotime($item->created_at))); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="9"><label style="font-size:16px;">Total Amount: </label><span style="font-weight: bold;font-size:16px;color:#719B5f;"> <?php echo e($total); ?></span></td>
                    </tr>
                    <tr>
                        <td colspan="9"><label style="font-size:16px;">Total Qty: </label><span style="font-weight: bold;font-size:16px;color:#719B5f;"> <?php echo e($total_qty); ?></span></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hisab165/public_html/tnborders.com/resources/views/backend/user-orders/order-detail.blade.php ENDPATH**/ ?>