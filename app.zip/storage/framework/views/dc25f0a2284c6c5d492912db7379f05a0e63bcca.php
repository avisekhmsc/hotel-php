<!doctype html>

<html lang="zxx">

<body>



    <!-- Mirrored from templates.envytheme.com/MFC/default/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 23 Mar 2023 04:57:27 GMT -->

<head>

    <!-- Required meta tags -->

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">



    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">

    

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/all-fontawesome.min.css')); ?>">



    <link rel="stylesheet" href="<?php echo e(asset('assets/css/flaticon.css')); ?>">

    

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.min.css')); ?>">

    

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/magnific-popup.min.css')); ?>">

     

    <!-- Nice Select CSS -->

     



    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">

    

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

    



    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.10.0/css/bootstrap-datepicker.min.css">



     <!-- jQuery UI datepicker -->

     <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">

    

    <title>MFC - Coworking Office Space HTML Template</title>



    <link rel="icon" type="image/png" href="assets/images/favicon.png">

    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js'></script>

</head>

    

    <?php echo $__env->yieldContent('content'); ?>



  

    <!-- End Footer Area -->

    

    <!-- Start Go Top Area -->

    <div class="go-top">

        <i class='bx bx-chevron-up'></i>

    </div>

    <!-- End Go Top Area -->

    

    

     

<script data-cfasync="false" src="../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/jquery-3.6.0.min.js"></script>

<script src="assets/js/modernizr.min.js"></script>

<script src="assets/js/bootstrap.bundle.min.js"></script>

<script src="assets/js/imagesloaded.pkgd.min.js"></script>

<script src="assets/js/jquery.magnific-popup.min.js"></script>

<script src="assets/js/isotope.pkgd.min.js"></script>

<script src="assets/js/jquery.appear.min.js"></script>

<script src="assets/js/jquery.easing.min.js"></script>

<script src="assets/js/owl.carousel.min.js"></script>

<script src="assets/js/counter-up.js"></script>

<script src="assets/js/wow.min.js"></script>

  <!-- Nice Select JS -->

  
<script src="assets/js/main.js"></script>

<script>

    $(document).ready(function(){

$('select').niceSelect();

    });

</script>

</body>



<!-- Mirrored from templates.envytheme.com/MFC/default/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 23 Mar 2023 04:57:43 GMT -->

</html><?php /**PATH E:\xampp\htdocs\new-laravel\resources\views/component/layout.blade.php ENDPATH**/ ?>