

<?php $__env->startSection('content'); ?>
<div class="layout-px-spacing">
    <div class="row layout-top-spacing" id="cancel-rowx">
        <div id="wizards_pills" class="col-lg-12">
            <div class="seperator-header">
               
                
            </div>
            <?php if(session()->get('error')): ?>
                <div class="alert alert-warning">
                    <?php echo e(session()->get('error')); ?>

                </div>
            <?php endif; ?>
        </div>
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 layout-spacing">
             <div class="statbox widget box box-shadow">
                 <div class="widget-content widget-content-area">
                     
                     <div id='calendar'></div>
                 </div>
             </div>
         </div>
     </div>
 </div>
 <?php
                $arr = array(); 
date_default_timezone_set('Asia/Kolkata');
$date = date("Y-m-d");
$time = date('h:i:s');
                foreach($scheduleList as $conference_booking){
                //   $dateCreate=date_create($conference_booking->date);
                //  $dateSub = date_sub($dateCreate,date_interval_create_from_date_string("1 day"));
                   
                array_push($arr,array(
                'title'=>$conference_booking->name,
                'start'=>$conference_booking->meeting_date.'T'.$conference_booking->time_from,
                'end'=>$conference_booking->date.'T'.$conference_booking->time_until,
                'backgroundColor'=>'green',
                'borderColor'=>'green'
                ));
                }
                
                ?>    
 <script>
         document.addEventListener('DOMContentLoaded', function() {
            let bg = 'background';
  let arr = <?php echo json_encode($arr); ?>;
      var calendarEl = document.getElementById('calendar');
      var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'timeGridWeek',
        selectable: true,
        // editable: true,
        // allDay:false,
        events: arr,
       });
       calendar.render();
    });
 </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\mfc2-laravel\resources\views/backend/schedule/schedule-list-show.blade.php ENDPATH**/ ?>