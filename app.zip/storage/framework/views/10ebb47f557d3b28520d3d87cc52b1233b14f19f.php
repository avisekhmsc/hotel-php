
<?php $__env->startSection('content'); ?>
        <!-- Start Preloader Area -->
        <div class="preloader">
            <div class="loader">
                <div class="shadow"></div>
                <div class="box"></div>
            </div>
        </div>
        <!-- End Preloader Area -->

        <!-- Start Top Header Area -->
        <div class="header-information">Header Information</div>
        
        <?php $page ='home';?>

        <?php echo $__env->make("component.menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <!-- Start Page Banner -->
        <div class="page-banner-area">
            <div class="container">
                <div class="page-banner-content">
                    <h2>Directory</h2>
                    
                    <ul class="pages-list">
                        <li><a href="index.php">Home</a></li>
                        <li>Directory</li>
                    </ul>
                </div>
            </div>
        </div>
         <!-- Start Services Details Area -->
         <section class="services-details-area ptb-100">
            <div class="container">
                <div class="services-details-overview">
                    <div class="row align-items-center">
                        <div class="col-lg-5 col-md-12">
                            <div class="services-details-image">
                               <a href="https://leftbrainwm.com/"  target="_blank"> <img src="assets/images/lbwm.jpg" alt="image"></a>
                            </div>
                        </div>
                        <div class="col-lg-7 col-md-12">
                            <div class="services-details-desc">
                            <a href="https://leftbrainwm.com/"  target="_blank"><h3>Left Brain Wealth Management  </h3></a>
                                <p>
                                    Left Brain is dedicated to providing investment management and strategic wealth planning. Simply put, we strive to be our client’s trusted advisor. As an Investment advisory firm, our primary focus is to provide unbiased opinions that are designed to achieve long term investment results. 
                                </p>
                                <p>CEO- Noland Langford, MBA,CFP</p>
                                <p> URL - <a href="https://leftbrainwm.com/"  target="_blank">leftbrainwm.com</a> </p>
                            </div>
                        </div>

                        
                    </div>
                </div>

                <div class="services-details-overview">
                    <div class="row align-items-center">
                        <div class="col-lg-5 col-md-12">
                            <div class="services-details-image">
                                <!-- <img src="assets/images/google.png" alt="image"> -->
                            </div>
                        </div>

                        <div class="col-lg-7 col-md-12">
                            <!-- <div class="services-details-desc">
                                <h3>Google</h3>
                                <p>CEO- China Thompson 
                                    </p>

  
                            </div> -->
                        </div>
                    </div>
                </div>   
            </div>
        </section>
        <!-- End Services Details Area -->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('component.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\mfc-laravel\resources\views/directory.blade.php ENDPATH**/ ?>